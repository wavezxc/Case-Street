import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import './App.css';
import { 
  Header, 
  MainPage, 
  InventoryPage,
  UpgradePage, 
  ContractsPage, 
  GiveawaysPage, 
  TournamentsPage 
} from './Components';
import { steamAPI } from './services/api';

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userInfo, setUserInfo] = useState(null);
  const [balance, setBalance] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Handle Steam callback with token first
    const urlParams = new URLSearchParams(window.location.search);
    const token = urlParams.get('token');
    
    if (token) {
      console.log('Steam callback token received:', token.substring(0, 20) + '...');
      // Store token with proper error handling
      try {
        localStorage.setItem('steam_token', token);
        console.log('Token stored in localStorage');
        // Clean URL immediately
        window.history.replaceState({}, document.title, window.location.pathname);
        
        // Use a small delay to ensure localStorage operation completes
        setTimeout(() => {
          console.log('Checking auth status after token storage');
          checkAuthStatus();
        }, 100);
      } catch (error) {
        console.error('Failed to store Steam token:', error);
        // Fallback: try to authenticate anyway
        checkAuthStatus();
      }
    } else {
      // Normal authentication check
      checkAuthStatus();
    }
  }, []);

  const checkAuthStatus = async () => {
    try {
      if (steamAPI.isAuthenticated()) {
        const response = await steamAPI.getProfile();
        const userData = response.data;
        
        setUserInfo({
          steamId: userData.steam_id,
          username: userData.username,
          avatar: userData.avatar
        });
        setBalance(userData.balance || 0);
        setIsLoggedIn(true);
        
        // Store user data
        localStorage.setItem('steam_user', JSON.stringify({
          steamId: userData.steam_id,
          username: userData.username,
          avatar: userData.avatar
        }));
      } else {
        // Reset state if not authenticated
        setIsLoggedIn(false);
        setUserInfo(null);
        setBalance(0);
      }
    } catch (error) {
      console.error('Auth check failed:', error);
      // Clear invalid tokens and reset state
      steamAPI.logout();
      setIsLoggedIn(false);
      setUserInfo(null);
      setBalance(0);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="text-2xl font-bold text-gray-800 mb-4">Case Street</div>
          <div className="text-gray-600">Загрузка...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="App min-h-screen bg-gray-50">
      <BrowserRouter>
        <Header 
          isLoggedIn={isLoggedIn}
          setIsLoggedIn={setIsLoggedIn}
          userInfo={userInfo}
          setUserInfo={setUserInfo}
          balance={balance}
          setBalance={setBalance}
        />
        <Routes>
          <Route 
            path="/" 
            element={
              <MainPage 
                balance={balance}
                setBalance={setBalance}
                isLoggedIn={isLoggedIn}
              />
            } 
          />
          <Route 
            path="/inventory" 
            element={
              isLoggedIn ? <InventoryPage /> : <div className="min-h-screen bg-gray-50 py-8 text-center">
                <div className="text-2xl font-bold text-gray-800 mb-4">Войдите через Steam</div>
                <p className="text-gray-600">Для просмотра инвентаря необходимо войти в систему</p>
              </div>
            } 
          />
          <Route path="/upgrade" element={<UpgradePage />} />
          <Route path="/contracts" element={<ContractsPage />} />
          <Route path="/giveaways" element={<GiveawaysPage />} />
          <Route path="/tournaments" element={<TournamentsPage />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;