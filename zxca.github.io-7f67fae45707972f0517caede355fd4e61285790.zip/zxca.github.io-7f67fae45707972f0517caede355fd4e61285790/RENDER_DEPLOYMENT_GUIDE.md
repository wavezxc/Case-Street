# 🚀 Руководство по развертыванию на Render

## Что изменилось
✅ **Адаптировано для PostgreSQL** - заменили MongoDB на PostgreSQL
✅ **Созданы конфигурационные файлы** для Render
✅ **Сохранена вся функциональность** - Steam авторизация, кейсы, инвентарь
✅ **UUID вместо ObjectID** - совместимость с PostgreSQL

## 📋 Подготовка к развертыванию

### Шаг 1: Загрузка кода на GitHub
1. Создайте новый репозиторий на GitHub
2. Загрузите весь код из папки `/app` в репозиторий
3. Убедитесь, что все файлы загружены, включая:
   - `render.yaml`
   - `backend/server_postgresql.py`
   - `backend/database_postgresql.py`
   - `backend/requirements.txt` (обновленный)

### Шаг 2: Регистрация на Render
1. Перейдите на [render.com](https://render.com)
2. Зарегистрируйтесь через GitHub
3. Подключите ваш репозиторий

### Шаг 3: Создание PostgreSQL базы данных
1. В дашборде Render нажмите "New +"
2. Выберите "PostgreSQL"
3. Параметры:
   - **Name**: `case-battle-db`
   - **Database**: `case_battle_db`
   - **User**: `case_battle_user`
   - **Plan**: Free
4. Нажмите "Create Database"
5. **Сохраните Connection String** - он понадобится!

### Шаг 4: Создание Backend Service
1. В дашборде нажмите "New +" → "Web Service"
2. Подключите ваш GitHub репозиторий
3. Параметры:
   - **Name**: `case-battle-backend`
   - **Environment**: `Python 3`
   - **Build Command**: `cd backend && pip install -r requirements.txt`
   - **Start Command**: `cd backend && uvicorn server_postgresql:app --host 0.0.0.0 --port 10000`
   - **Plan**: Free

4. **Environment Variables** (очень важно!):
   ```
   DATABASE_URL = [Connection String из шага 3]
   STEAM_API_KEY = 635B407F83511374FA9731B15F7F8BFB
   SESSION_SECRET = secure_random_string_for_jwt_signing_very_long_key_123456
   CALLBACK_URL = https://your-backend-name.onrender.com/api/auth/steam/callback
   FRONTEND_URL = https://your-frontend-name.onrender.com
   ```

5. Нажмите "Create Web Service"

### Шаг 5: Создание Frontend Service
1. В дашборде нажмите "New +" → "Static Site"
2. Подключите тот же GitHub репозиторий
3. Параметры:
   - **Name**: `case-battle-frontend`
   - **Build Command**: `cd frontend && yarn install && yarn build`
   - **Publish Directory**: `frontend/build`
   - **Plan**: Free

4. **Environment Variables**:
   ```
   REACT_APP_BACKEND_URL = https://your-backend-name.onrender.com
   NODE_ENV = production
   ```

5. Нажмите "Create Static Site"

### Шаг 6: Обновление URL-ов
После создания сервисов вы получите реальные URL:
- Backend: `https://case-battle-backend-xxx.onrender.com`
- Frontend: `https://case-battle-frontend-xxx.onrender.com`

**Обновите переменные окружения**:
1. Откройте Backend Service → Settings → Environment
2. Обновите:
   ```
   CALLBACK_URL = https://ваш-backend-url.onrender.com/api/auth/steam/callback
   FRONTEND_URL = https://ваш-frontend-url.onrender.com
   ```

3. Откройте Frontend Service → Settings → Environment
4. Обновите:
   ```
   REACT_APP_BACKEND_URL = https://ваш-backend-url.onrender.com
   ```

### Шаг 7: Настройка UptimeRobot (опционально)
Чтобы сайт не "засыпал":
1. Зарегистрируйтесь на [uptimerobot.com](https://uptimerobot.com)
2. Добавьте новый монитор:
   - **Type**: HTTP(s)
   - **URL**: `https://ваш-backend-url.onrender.com/api/health`
   - **Monitoring Interval**: 5 минут
3. Это будет пинговать ваш сайт каждые 5 минут!

## 🔧 Локальное тестирование (опционально)

Если хотите протестировать локально перед деплоем:

```bash
# Установка PostgreSQL локально
./setup_local_postgres.sh

# Запуск backend с PostgreSQL
cd backend
cp .env.local .env
python -m uvicorn server_postgresql:app --reload --host 0.0.0.0 --port 8001

# Запуск frontend (в новом терминале)
cd frontend
yarn start
```

## 🎯 Что получите в итоге

✅ **Полностью бесплатное решение**
✅ **Автоматические деплои** из GitHub
✅ **HTTPS сертификаты** автоматически
✅ **PostgreSQL база данных** (500MB бесплатно)
✅ **Все функции сохранены**: Steam авторизация, кейсы, инвентарь
✅ **24/7 работа** (с UptimeRobot)

## 🚨 Важные моменты

1. **Время запуска**: Бесплатные сервисы на Render "засыпают" после 15 минут бездействия
   - Первый посетитель будет ждать ~30 секунд пока сервис "проснется"
   - UptimeRobot решает эту проблему

2. **Ограничения бесплатного плана**:
   - 750 часов работы в месяц
   - PostgreSQL: 500MB хранилища
   - Bandwidth: 100GB/месяц

3. **Steam API ключ**: Убедитесь что ключ `635B407F83511374FA9731B15F7F8BFB` активен

## 🎉 Готово!

После выполнения всех шагов у вас будет:
- **Backend**: `https://ваш-backend.onrender.com`
- **Frontend**: `https://ваш-frontend.onrender.com`
- **Database**: PostgreSQL на Render
- **Мониторинг**: UptimeRobot (опционально)

Ваше приложение для открытия кейсов CS:GO будет работать 24/7 совершенно бесплатно! 🚀