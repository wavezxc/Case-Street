from fastapi import FastAPI, APIRouter, Request, HTTPException, Depends
from fastapi.security import HTTPBearer
from fastapi.responses import RedirectResponse
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
import os
import sys
import logging
from pathlib import Path
from pydantic import BaseModel, Field
from typing import List, Optional
import uuid
from datetime import datetime
import aiohttp
import json

# Add current directory to Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Import custom modules
import steam_auth
from models import *
from database_postgresql import *
from skins_database import get_random_skin_by_weight, get_skins_for_case, CSGO_SKINS_DATABASE

steam_auth_instance = steam_auth.steam_auth

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# Create the main app without a prefix
app = FastAPI(title="Case Battle API")

# Create a router with the /api prefix
api_router = APIRouter(prefix="/api")

# Security
security = HTTPBearer()

# Initialize database on startup
@app.on_event("startup")
async def startup_event():
    try:
        await init_db()
        print("Database initialized successfully")
    except Exception as e:
        print(f"Database initialization failed: {e}")
        print("Continuing without database connection for testing purposes")

@app.on_event("shutdown")
async def shutdown_event():
    await close_db()
    print("Database connection closed")

# Dependency to get current user
async def get_current_user(token: str = Depends(security)):
    """Get current authenticated user"""
    try:
        payload = steam_auth_instance.verify_jwt_token(token.credentials)
        steam_id = payload.get('steam_id')
        if not steam_id:
            raise HTTPException(status_code=401, detail="Invalid token")
        
        user = await get_user_by_steam_id(steam_id)
        if not user:
            raise HTTPException(status_code=404, detail="User not found")
        
        return user
    except Exception as e:
        raise HTTPException(status_code=401, detail=str(e))

# Steam Authentication Routes
@api_router.get("/auth/steam/login", response_model=SteamLoginResponse)
async def steam_login():
    """Initiate Steam login"""
    # Explicitly use the callback URL from environment
    callback_url = os.environ.get('CALLBACK_URL')
    if not callback_url:
        callback_url = "https://zxca-github-io.onrender.com/api/auth/steam/callback"
    login_url = steam_auth_instance.generate_steam_login_url(callback_url)
    return SteamLoginResponse(login_url=login_url)

@api_router.get("/auth/steam/callback")
async def steam_callback(request: Request):
    """Handle Steam authentication callback"""
    try:
        query_params = dict(request.query_params)
        
        # Verify Steam login
        steam_id = await steam_auth_instance.verify_steam_login(query_params)
        if not steam_id:
            raise HTTPException(status_code=403, detail="Steam authentication failed")
        
        # Get user profile from Steam
        profile_data = await steam_auth_instance.get_steam_profile(steam_id)
        
        # Create or update user in database
        user = await create_or_update_user(steam_id, profile_data)
        
        # Generate JWT token
        token = steam_auth_instance.generate_jwt_token(steam_id, profile_data)
        
        # Redirect to frontend with token
        frontend_url = os.environ.get('FRONTEND_URL', "http://localhost:3000")
        redirect_url = f"{frontend_url}?token={token}"
        return RedirectResponse(url=redirect_url)
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Steam callback error: {e}")
        # Redirect to frontend with error
        frontend_url = os.environ.get('FRONTEND_URL', "http://localhost:3000")
        redirect_url = f"{frontend_url}?error=auth_failed"
        return RedirectResponse(url=redirect_url)

# User Routes
@api_router.get("/user/profile")
async def get_profile(current_user = Depends(get_current_user)):
    """Get current user profile"""
    return current_user

@api_router.get("/user/inventory")
async def get_inventory(current_user = Depends(get_current_user)):
    """Get user inventory"""
    inventory = await get_user_inventory(str(current_user["id"]))
    return {"items": inventory}

@api_router.post("/user/balance/add")
async def add_balance(amount: int, current_user = Depends(get_current_user)):
    """Add balance to user account (amount in kopecks)"""
    if amount <= 0:
        raise HTTPException(status_code=400, detail="Amount must be positive")
    
    success = await update_user_balance(current_user["steam_id"], amount)
    if success:
        updated_user = await get_user_by_steam_id(current_user["steam_id"])
        return {"success": True, "new_balance": updated_user["balance"]}
    else:
        raise HTTPException(status_code=500, detail="Failed to update balance")

# Steam Market Integration
async def get_steam_market_price(market_hash_name: str):
    """Get item price from Steam Market"""
    url = "https://steamcommunity.com/market/priceoverview/"
    params = {
        "appid": 730,  # CS2 app ID
        "currency": 5,  # RUB
        "market_hash_name": market_hash_name
    }
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url, params=params) as response:
                if response.status == 200:
                    data = await response.json()
                    price_text = data.get("lowest_price", "0 pуб.")
                    # Extract numeric value and convert to kopecks
                    import re
                    price_match = re.search(r'(\d+)', price_text.replace(',', ''))
                    if price_match:
                        return int(float(price_match.group(1)) * 100)
                return 0
    except Exception as e:
        print(f"Error fetching Steam price: {e}")
        return 0

# Skin Management endpoints
@api_router.get("/skins")
async def get_all_available_skins():
    """Get all available skins in the database"""
    from skins_database import get_all_skins
    skins = get_all_skins()
    
    # Группируем скины по редкости для удобства
    skins_by_rarity = {
        "mythical": [],
        "legendary": [],
        "epic": [],
        "rare": [],
        "common": []
    }
    
    for skin in skins:
        rarity = skin.get("rarity", "common")
        if rarity in skins_by_rarity:
            skins_by_rarity[rarity].append(skin)
    
    return {
        "total_skins": len(skins),
        "skins_by_rarity": skins_by_rarity,
        "all_skins": skins
    }

@api_router.get("/skins/rarity/{rarity}")
async def get_skins_by_rarity_endpoint(rarity: str):
    """Get skins by specific rarity"""
    from skins_database import get_skins_by_rarity
    
    valid_rarities = ["mythical", "legendary", "epic", "rare", "common"]
    if rarity not in valid_rarities:
        raise HTTPException(status_code=400, detail=f"Invalid rarity. Must be one of: {valid_rarities}")
    
    skins = get_skins_by_rarity(rarity)
    return {
        "rarity": rarity,
        "count": len(skins),
        "skins": skins
    }

# Case Management
@api_router.get("/cases")
async def get_cases():
    """Get all available cases with updated prices"""
    cases_data = [
        {
            "id": "1",
            "name": "СТАРТОВЫЙ КЕЙС",
            "items": 25,
            "price": 1500,  # 15 RUB
            "image": "https://community.akamai.steamstatic.com/economy/image/-9a81dlWLwJ2UUGcVs_nsVtzdOEdtWwKGZZLQHTxDZ7I56KU0Zwwo4NUX4oFJZEHLbXH5ApeO4YmlhxYQknCRvCo04DEVlxkKgpou-6kejhz2v_Nfz5H_uO1gb-Gw_alIITCmX5d_MR6mOzG-oLw2w2yrUo5N2j0LI6XdAU-YluE-AS9kOy918Pu6M6YwSE26CB3sGGdwULdGVNUiw/360fx360f",
            "is_new": True,
            "description": "Базовые скины для новичков",
            "case_type": "low"
        },
        {
            "id": "2", 
            "name": "УНИВЕРСАЛЬНЫЙ КЕЙС",
            "items": 35,
            "price": 7500,  # 75 RUB
            "image": "https://community.akamai.steamstatic.com/economy/image/-9a81dlWLwJ2UUGcVs_nsVtzdOEdtWwKGZZLQHTxDZ7I56KU0Zwwo4NUX4oFJZEHLbXH5ApeO4YmlhxYQknCRvCo04DEVlxkKgpot621FAR17PLfYQJD_9W7m5a0mvLwOq7c2DMBupQn2eqVotqkiwHiqhdlMmigJtOWJwE5Zw3X8wS-yea8jcDo7c7XiSw0g89L9us/360fx360f",
            "is_new": True,
            "description": "Смесь редких и обычных скинов",
            "case_type": "medium"
        },
        {
            "id": "3",
            "name": "ПРЕМИУМ КОЛЛЕКЦИЯ", 
            "items": 42,
            "price": 25000,  # 250 RUB
            "image": "https://community.akamai.steamstatic.com/economy/image/-9a81dlWLwJ2UUGcVs_nsVtzdOEdtWwKGZZLQHTxDZ7I56KU0Zwwo4NUX4oFJZEHLbXH5ApeO4YmlhxYQknCRvCo04DEVlxkKgpovbSsLQJf3qr3czxb49KzgL-ImOX3NrfUhGRu5Mx2gv2P8Y3w2gS3rkVsYzqlI9edJgI2NAmE-VK3wOe9h8W6uJTJzmwj5Hc3nWGdwUKnJ-gWGw/360fx360f",
            "is_new": True,
            "description": "Редкие скины и эпические винтовки",
            "case_type": "medium"
        },
        {
            "id": "4",
            "name": "ЛЕГЕНДАРНАЯ СЕРИЯ",
            "items": 28, 
            "price": 55000,  # 550 RUB
            "image": "https://community.akamai.steamstatic.com/economy/image/-9a81dlWLwJ2UUGcVs_nsVtzdOEdtWwKGZZLQHTxDZ7I56KU0Zwwo4NUX4oFJZEHLbXH5ApeO4YmlhxYQknCRvCo04DEVlxkKgpovbSsLQJf0Ob3dDFL7929ldaOwfX3MLrFnm5u5Mx2gv2P8I2p3g3l-kY9N2yiI4KcdVVvNQyC_FO2kr3ohpHptZ6fzmwj5HcqeFN1sQ/360fx360f",
            "is_new": True,
            "description": "Легендарные винтовки и эпические скины",
            "case_type": "high"
        },
        {
            "id": "5",
            "name": "КОРОЛЕВСКИЙ КЕЙС",
            "items": 20,
            "price": 150000,  # 1,500 RUB
            "image": "https://community.akamai.steamstatic.com/economy/image/-9a81dlWLwJ2UUGcVs_nsVtzdOEdtWwKGZZLQHTxDZ7I56KU0Zwwo4NUX4oFJZEHLbXH5ApeO4YmlhxYQknCRvCo04DEVlxkKgpopuP1FA957ODYfi9W7927kYyDgvun4IrqyT5Q5sFo2u2T8I-niwHg8hI5ZGv3ddSSI1I5ZwzY-FO2l-e8h5C4vczXiSw0Oj2SzDo/360fx360f",
            "is_new": True,
            "description": "Только самые дорогие скины и ножи!",
            "case_type": "high"
        },
        {
            "id": "6",
            "name": "НОЖЕВОЙ КЕЙС 🔥",
            "items": 15,
            "price": 500000,  # 5,000 RUB  
            "image": "https://community.akamai.steamstatic.com/economy/image/-9a81dlWLwJ2UUGcVs_nsVtzdOEdtWwKGZZLQHTxDZ7I56KU0Zwwo4NUX4oFJZEHLbXH5ApeO4YmlhxYQknCRvCo04DEVlxkKgpopuP1FAR17P7NdTRH-t26q4SClvD7Ib6ukmJE6ct0h-zF_Jn4xlCx-UA-azjxdICWegVtYlyC-lK7wrnshZK06Z_XiSw0PXJwqWo/360fx360f",
            "is_new": True,
            "description": "ГАРАНТИРОВАННЫЙ НОЖ В КАЖДОМ КЕЙСЕ!",
            "case_type": "knife_only"
        }
    ]
    return {"cases": cases_data}

# Case opening with realistic CS:GO items
@api_router.post("/cases/{case_id}/open")
async def open_case(case_id: str, current_user = Depends(get_current_user)):
    """Open a case and get random item"""
    # Get case data
    cases_response = await get_cases()
    cases_data = cases_response["cases"]
    case_data = next((c for c in cases_data if c["id"] == case_id), None)
    
    if not case_data:
        raise HTTPException(status_code=404, detail="Case not found")
    
    # Check user balance
    if current_user["balance"] < case_data["price"]:
        raise HTTPException(status_code=400, detail="Insufficient balance")
    
    # Deduct case price from balance
    await update_user_balance(current_user["steam_id"], -case_data["price"])
    
    # Определяем логику выбора скинов в зависимости от кейса
    case_type = case_data.get("case_type", "medium")
    
    if case_type == "knife_only":
        # Специальный ножевой кейс - только ножи
        selected_item = random.choice(CSGO_SKINS_DATABASE["knives"])
    elif case_type == "low":
        # Дешевый кейс - больше обычных скинов
        rarity_weights = {
            "common": 60,
            "rare": 35,
            "epic": 5,
            "legendary": 0,
            "mythical": 0
        }
        selected_item = get_weighted_skin_selection(rarity_weights)
    elif case_type == "medium":
        # Средний кейс - сбалансированный
        rarity_weights = {
            "common": 40,
            "rare": 35,
            "epic": 20,
            "legendary": 4,
            "mythical": 1
        }
        selected_item = get_weighted_skin_selection(rarity_weights)
    elif case_type == "high":
        # Дорогой кейс - больше редких скинов
        rarity_weights = {
            "common": 20,
            "rare": 30,
            "epic": 30,
            "legendary": 15,
            "mythical": 5
        }
        selected_item = get_weighted_skin_selection(rarity_weights)
    else:
        # По умолчанию
        selected_item = get_random_skin_by_weight()
    
    # Add item to user inventory
    await add_item_to_inventory(str(current_user["id"]), selected_item)
    
    # Save case result
    await save_case_result(str(current_user["id"]), case_id, selected_item)
    
    return {
        "success": True,
        "item": selected_item,
        "remaining_balance": current_user["balance"] - case_data["price"]
    }

def get_weighted_skin_selection(rarity_weights):
    """Выбирает скин на основе весов редкости"""
    import random
    from skins_database import get_all_skins
    
    all_skins = get_all_skins()
    weighted_skins = []
    
    for skin in all_skins:
        weight = rarity_weights.get(skin["rarity"], 1)
        weighted_skins.extend([skin] * weight)
    
    return random.choice(weighted_skins)

# Health check endpoint
@api_router.get("/health")
async def health_check():
    """Health check endpoint"""
    db_healthy = await check_db_health()
    return {
        "status": "healthy" if db_healthy else "unhealthy",
        "database": "connected" if db_healthy else "disconnected"
    }

# Add original routes for compatibility
@api_router.get("/")
async def root():
    return {"message": "Case Battle API with PostgreSQL"}

@api_router.post("/status", response_model=StatusCheck)
async def create_status_check(input: StatusCheckCreate):
    status_dict = input.dict()
    status_obj = StatusCheck(**status_dict)
    # For now, we'll just return the status without saving to database
    # since we're migrating from MongoDB collections to PostgreSQL tables
    return status_obj

@api_router.get("/status", response_model=List[StatusCheck])
async def get_status_checks():
    # Return empty list for now - can be implemented later with PostgreSQL
    return []

# Include the router in the main app
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)