import asyncpg
import os
from typing import Optional, List, Dict, Any
from datetime import datetime
import json
import uuid

# PostgreSQL connection
DATABASE_URL = os.environ.get('DATABASE_URL', 'postgresql://localhost:5432/case_battle_db')

# Connection pool
pool = None

async def init_db():
    """Initialize database connection pool"""
    global pool
    try:
        pool = await asyncpg.create_pool(DATABASE_URL)
        
        # Create tables if they don't exist
        async with pool.acquire() as conn:
            await conn.execute('''
                CREATE TABLE IF NOT EXISTS users (
                    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                    steam_id VARCHAR(255) UNIQUE NOT NULL,
                    username VARCHAR(255) NOT NULL,
                    avatar TEXT,
                    profile_url TEXT,
                    balance BIGINT DEFAULT 0,
                    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
                    last_login TIMESTAMP WITH TIME ZONE DEFAULT NOW()
                )
            ''')
            
            await conn.execute('''
                CREATE TABLE IF NOT EXISTS inventory (
                    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
                    name VARCHAR(255) NOT NULL,
                    rarity VARCHAR(50),
                    price BIGINT,
                    market_hash_name VARCHAR(255),
                    image_url TEXT,
                    color_class VARCHAR(100),
                    obtained_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
                )
            ''')
            
            await conn.execute('''
                CREATE TABLE IF NOT EXISTS case_results (
                    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
                    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
                    case_id VARCHAR(50) NOT NULL,
                    item_name VARCHAR(255) NOT NULL,
                    item_rarity VARCHAR(50),
                    item_price BIGINT,
                    item_market_hash_name VARCHAR(255),
                    item_image_url TEXT,
                    item_color_class VARCHAR(100),
                    opened_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
                )
            ''')
            
            # Create indexes for better performance
            await conn.execute('CREATE INDEX IF NOT EXISTS idx_users_steam_id ON users(steam_id)')
            await conn.execute('CREATE INDEX IF NOT EXISTS idx_inventory_user_id ON inventory(user_id)')
            await conn.execute('CREATE INDEX IF NOT EXISTS idx_case_results_user_id ON case_results(user_id)')
        return True
    except Exception as e:
        print(f"Database initialization error: {e}")
        return False

async def close_db():
    """Close database connection pool"""
    global pool
    if pool:
        await pool.close()

def dict_row_to_dict(row: asyncpg.Record) -> dict:
    """Convert asyncpg Record to dict"""
    return dict(row)

async def create_or_update_user(steam_id: str, profile_data: dict) -> dict:
    """Create new user or update existing user"""
    async with pool.acquire() as conn:
        # Check if user exists
        existing_user = await conn.fetchrow(
            "SELECT * FROM users WHERE steam_id = $1", steam_id
        )
        
        user_data = {
            'steam_id': steam_id,
            'username': profile_data.get("personaname", "Unknown"),
            'avatar': profile_data.get("avatarfull", ""),
            'profile_url': profile_data.get("profileurl", ""),
            'last_login': datetime.utcnow()
        }
        
        if existing_user:
            # Update existing user
            await conn.execute('''
                UPDATE users 
                SET username = $2, avatar = $3, profile_url = $4, last_login = $5 
                WHERE steam_id = $1
            ''', steam_id, user_data['username'], user_data['avatar'], 
                user_data['profile_url'], user_data['last_login'])
            
            updated_user = await conn.fetchrow("SELECT * FROM users WHERE steam_id = $1", steam_id)
            return dict_row_to_dict(updated_user)
        else:
            # Create new user
            user_data['balance'] = 0
            user_data['created_at'] = datetime.utcnow()
            
            new_user_id = await conn.fetchval('''
                INSERT INTO users (steam_id, username, avatar, profile_url, balance, created_at, last_login)
                VALUES ($1, $2, $3, $4, $5, $6, $7)
                RETURNING id
            ''', steam_id, user_data['username'], user_data['avatar'], 
                user_data['profile_url'], user_data['balance'], 
                user_data['created_at'], user_data['last_login'])
            
            new_user = await conn.fetchrow("SELECT * FROM users WHERE id = $1", new_user_id)
            return dict_row_to_dict(new_user)

async def get_user_by_steam_id(steam_id: str) -> Optional[dict]:
    """Get user by Steam ID"""
    async with pool.acquire() as conn:
        user = await conn.fetchrow("SELECT * FROM users WHERE steam_id = $1", steam_id)
        return dict_row_to_dict(user) if user else None

async def update_user_balance(steam_id: str, amount: int) -> bool:
    """Update user balance (amount in kopecks)"""
    async with pool.acquire() as conn:
        result = await conn.execute(
            "UPDATE users SET balance = balance + $1 WHERE steam_id = $2",
            amount, steam_id
        )
        return result == "UPDATE 1"

async def add_item_to_inventory(user_id: str, item_data: dict) -> str:
    """Add item to user inventory"""
    async with pool.acquire() as conn:
        item_id = await conn.fetchval('''
            INSERT INTO inventory (user_id, name, rarity, price, market_hash_name, image_url, color_class, obtained_at)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
            RETURNING id
        ''', 
            uuid.UUID(user_id),
            item_data['name'], 
            item_data['rarity'], 
            item_data['price'],
            item_data['market_hash_name'],
            item_data['image_url'],
            item_data['color_class'],
            datetime.utcnow()
        )
        return str(item_id)

async def get_user_inventory(user_id: str) -> list:
    """Get all items in user inventory"""
    async with pool.acquire() as conn:
        rows = await conn.fetch("SELECT * FROM inventory WHERE user_id = $1 ORDER BY obtained_at DESC", uuid.UUID(user_id))
        return [dict_row_to_dict(row) for row in rows]

async def save_case_result(user_id: str, case_id: str, item_data: dict) -> str:
    """Save case opening result"""
    async with pool.acquire() as conn:
        result_id = await conn.fetchval('''
            INSERT INTO case_results (user_id, case_id, item_name, item_rarity, item_price, 
                                    item_market_hash_name, item_image_url, item_color_class, opened_at)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
            RETURNING id
        ''',
            uuid.UUID(user_id),
            case_id,
            item_data['name'],
            item_data['rarity'],
            item_data['price'],
            item_data['market_hash_name'],
            item_data['image_url'],
            item_data['color_class'],
            datetime.utcnow()
        )
        return str(result_id)

# Compatibility functions for the existing API
async def get_cases_collection():
    """Mock function for cases collection - we'll use static data instead"""
    return None

# Health check function
async def check_db_health() -> bool:
    """Check if database connection is healthy"""
    global pool
    try:
        if pool is None:
            return False
            
        async with pool.acquire() as conn:
            await conn.fetchval("SELECT 1")
        return True
    except Exception as e:
        print(f"Database health check failed: {e}")
        return False