#!/bin/bash

# Local PostgreSQL Setup Script for Testing

echo "🐘 Setting up local PostgreSQL for testing..."

# Install PostgreSQL if not present (Ubuntu/Debian)
if ! command -v psql &> /dev/null; then
    echo "Installing PostgreSQL..."
    sudo apt-get update
    sudo apt-get install -y postgresql postgresql-contrib
fi

# Start PostgreSQL service
sudo service postgresql start

# Create database and user
echo "Creating database and user..."
sudo -u postgres psql -c "CREATE DATABASE case_battle_db;"
sudo -u postgres psql -c "CREATE USER case_battle_user WITH ENCRYPTED PASSWORD 'case_battle_pass';"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE case_battle_db TO case_battle_user;"
sudo -u postgres psql -c "ALTER USER case_battle_user CREATEDB;"

# Create local .env file for testing
echo "Creating local .env file..."
cat > /app/backend/.env.local << EOF
DATABASE_URL=postgresql://case_battle_user:case_battle_pass@localhost:5432/case_battle_db
STEAM_API_KEY=635B407F83511374FA9731B15F7F8BFB
SESSION_SECRET=secure_random_string_for_jwt_signing_very_long_key_123456
CALLBACK_URL=http://localhost:8001/api/auth/steam/callback
FRONTEND_URL=http://localhost:3000
EOF

echo "✅ PostgreSQL setup complete!"
echo "📝 Local database URL: postgresql://case_battle_user:case_battle_pass@localhost:5432/case_battle_db"
echo ""
echo "🚀 To test locally:"
echo "1. cd /app/backend"
echo "2. cp .env.local .env"
echo "3. python -m uvicorn server_postgresql:app --reload --host 0.0.0.0 --port 8001"
echo ""
echo "🌐 To test frontend:"
echo "1. cd /app/frontend"
echo "2. Update .env to point to http://localhost:8001"
echo "3. yarn start"