#!/usr/bin/env python3
"""
Тестовый скрипт для проверки PostgreSQL подключения
"""
import asyncio
import asyncpg
import os
from datetime import datetime

# Простой тест PostgreSQL подключения
async def test_postgresql_connection():
    """Тест подключения к PostgreSQL"""
    DATABASE_URL = "postgresql://case_battle_user:case_battle_pass@localhost:5432/case_battle_db"
    
    try:
        print("🔌 Подключение к PostgreSQL...")
        conn = await asyncpg.connect(DATABASE_URL)
        
        # Тест простого запроса
        result = await conn.fetchval("SELECT version()")
        print(f"✅ PostgreSQL подключение успешно!")
        print(f"📊 Версия: {result}")
        
        # Создание тестовой таблицы
        await conn.execute('''
            CREATE TABLE IF NOT EXISTS test_table (
                id SERIAL PRIMARY KEY,
                name VARCHAR(100),
                created_at TIMESTAMP DEFAULT NOW()
            )
        ''')
        print("✅ Тестовая таблица создана")
        
        # Вставка тестовых данных
        await conn.execute(
            "INSERT INTO test_table (name) VALUES ($1)", 
            "Test User"
        )
        print("✅ Тестовые данные вставлены")
        
        # Проверка данных
        rows = await conn.fetch("SELECT * FROM test_table")
        print(f"✅ Найдено записей: {len(rows)}")
        
        # Очистка
        await conn.execute("DROP TABLE test_table")
        print("✅ Тестовая таблица удалена")
        
        await conn.close()
        print("🎉 Все тесты пройдены успешно!")
        return True
        
    except Exception as e:
        print(f"❌ Ошибка подключения: {e}")
        return False

# Тест импорта наших модулей
def test_imports():
    """Тест импорта наших модулей"""
    try:
        print("📦 Тестирование импорта модулей...")
        
        # Проверяем database_postgresql
        import database_postgresql
        print("✅ database_postgresql импортирован")
        
        # Проверяем server_postgresql
        import server_postgresql
        print("✅ server_postgresql импортирован")
        
        # Проверяем steam_auth
        import steam_auth
        print("✅ steam_auth импортирован")
        
        print("🎉 Все модули успешно импортированы!")
        return True
        
    except Exception as e:
        print(f"❌ Ошибка импорта: {e}")
        return False

async def main():
    """Основная функция тестирования"""
    print("🧪 Запуск тестов адаптации PostgreSQL...")
    print("=" * 50)
    
    # Тест импортов
    imports_ok = test_imports()
    print()
    
    # Тест PostgreSQL (только если импорты прошли)
    if imports_ok:
        db_ok = await test_postgresql_connection()
    else:
        db_ok = False
    
    print("=" * 50)
    if imports_ok and db_ok:
        print("🎉 ВСЕ ТЕСТЫ ПРОЙДЕНЫ! Приложение готово к деплою на Render!")
    else:
        print("⚠️  Некоторые тесты не прошли. Проверьте настройки.")
    
    return imports_ok and db_ok

if __name__ == "__main__":
    # Добавляем путь к модулям
    import sys
    sys.path.append('/app/backend')
    
    # Запускаем тесты
    asyncio.run(main())