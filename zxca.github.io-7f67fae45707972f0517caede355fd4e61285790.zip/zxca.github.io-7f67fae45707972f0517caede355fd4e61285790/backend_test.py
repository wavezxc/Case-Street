#!/usr/bin/env python3
import requests
import json
import time
import os
import sys
from urllib.parse import urlparse, parse_qs

# Use the backend URL from the frontend .env file
def get_backend_url():
    with open('/app/frontend/.env', 'r') as f:
        for line in f:
            if line.startswith('REACT_APP_BACKEND_URL='):
                return line.strip().split('=')[1]
    return None

# For testing purposes, we'll use the local server
BACKEND_URL = "http://localhost:8001"
BASE_URL = f"{BACKEND_URL}/api"
print(f"Using backend URL: {BASE_URL}")

# Test results
test_results = {
    "passed": 0,
    "failed": 0,
    "tests": []
}

# Helper function to add test result
def add_test_result(name, passed, response=None, error=None):
    status = "PASSED" if passed else "FAILED"
    test_results["tests"].append({
        "name": name,
        "status": status,
        "response": response.json() if response and passed else None,
        "error": str(error) if error else (response.text if response and not passed else None)
    })
    
    if passed:
        test_results["passed"] += 1
        print(f"✅ {name}: {status}")
    else:
        test_results["failed"] += 1
        print(f"❌ {name}: {status}")
        if error:
            print(f"   Error: {error}")
        elif response:
            print(f"   Response: {response.status_code} - {response.text[:200]}")

# Test basic API endpoint
def test_base_endpoint():
    try:
        response = requests.get(f"{BASE_URL}/")
        add_test_result("Base API Endpoint", response.status_code == 200, response)
        return response.json()
    except Exception as e:
        add_test_result("Base API Endpoint", False, error=e)
        return None

# Test status endpoints
def test_status_endpoints():
    # GET /api/status
    try:
        response = requests.get(f"{BASE_URL}/status")
        add_test_result("GET /api/status", response.status_code == 200, response)
    except Exception as e:
        add_test_result("GET /api/status", False, error=e)
    
    # POST /api/status
    try:
        data = {"client_name": "backend_test_script"}
        response = requests.post(f"{BASE_URL}/status", json=data)
        add_test_result("POST /api/status", response.status_code == 200, response)
    except Exception as e:
        add_test_result("POST /api/status", False, error=e)

# Test Steam authentication login URL
def test_steam_login():
    try:
        response = requests.get(f"{BASE_URL}/auth/steam/login")
        
        # Print response for debugging
        print(f"Steam Login Response: {response.status_code}")
        print(f"Response content: {response.text[:200]}")
        
        # Check if response is successful and contains login_url
        if response.status_code == 200:
            try:
                data = response.json()
                if "login_url" in data:
                    login_url = data["login_url"]
                    
                    # Verify the login URL contains required OpenID parameters
                    parsed_url = urlparse(login_url)
                    query_params = parse_qs(parsed_url.query)
                    
                    required_params = [
                        "openid.ns", 
                        "openid.mode", 
                        "openid.return_to", 
                        "openid.realm", 
                        "openid.identity", 
                        "openid.claimed_id"
                    ]
                    
                    all_params_present = all(param in query_params for param in required_params)
                    
                    # Verify the callback URL is correctly configured
                    callback_url = query_params.get("openid.return_to", [""])[0]
                    expected_callback = "https://zxca-github-io.onrender.com/api/auth/steam/callback"
                    callback_correct = callback_url == expected_callback
                    
                    if not callback_correct:
                        print(f"⚠️ Callback URL mismatch:")
                        print(f"  Expected: {expected_callback}")
                        print(f"  Actual: {callback_url}")
                    
                    add_test_result("Steam Login URL", 
                                   response.status_code == 200 and all_params_present and callback_correct, 
                                   response)
                    
                    return login_url
                else:
                    add_test_result("Steam Login URL", False, response, 
                                   error="Response does not contain login_url field")
                    return None
            except json.JSONDecodeError as e:
                add_test_result("Steam Login URL", False, response, 
                               error=f"Invalid JSON response: {e}")
                return None
        else:
            add_test_result("Steam Login URL", False, response)
            return None
    except Exception as e:
        add_test_result("Steam Login URL", False, error=e)
        return None

# Test Steam callback URL accessibility
def test_steam_callback_endpoint():
    try:
        # We can't actually test the full callback flow without a real Steam login,
        # but we can check if the endpoint exists and is accessible
        callback_url = f"{BASE_URL}/auth/steam/callback"
        
        # Make a GET request to the callback URL without parameters
        # We expect a 400 or similar error, but not a 404 (Not Found)
        response = requests.get(callback_url)
        
        # If we get a 404, the endpoint doesn't exist
        # Any other status code means the endpoint exists but needs proper parameters
        endpoint_exists = response.status_code != 404
        
        if endpoint_exists:
            add_test_result("Steam Callback Endpoint", True)
            print(f"Steam callback endpoint exists at {callback_url}")
            return True
        else:
            add_test_result("Steam Callback Endpoint", False, 
                           error=f"Steam callback endpoint not found (404) at {callback_url}")
            return False
    except Exception as e:
        add_test_result("Steam Callback Endpoint", False, error=e)
        return False

# Test cases API
def test_cases_api():
    try:
        response = requests.get(f"{BASE_URL}/cases")
        
        # Check if response is successful and contains cases
        if response.status_code == 200 and "cases" in response.json():
            cases = response.json()["cases"]
            
            # Verify cases have required fields and proper price format
            valid_cases = all(
                isinstance(case.get("id"), str) and
                isinstance(case.get("name"), str) and
                isinstance(case.get("price"), int) and
                isinstance(case.get("image"), str) and
                case.get("image").startswith("https://community.akamai.steamstatic.com/")
                for case in cases
            )
            
            add_test_result("Cases API", 
                           response.status_code == 200 and valid_cases, 
                           response)
            
            return cases
        else:
            add_test_result("Cases API", False, response)
            return None
    except Exception as e:
        add_test_result("Cases API", False, error=e)
        return None

# Test skins API endpoints
def test_skins_api():
    # Test /api/skins endpoint
    try:
        response = requests.get(f"{BASE_URL}/skins")
        
        if response.status_code == 200:
            data = response.json()
            
            # Verify the response contains the expected fields
            valid_response = (
                "total_skins" in data and
                "skins_by_rarity" in data and
                "all_skins" in data
            )
            
            # Verify we have skins in each rarity category
            rarities = ["mythical", "legendary", "epic", "rare", "common"]
            has_all_rarities = all(rarity in data["skins_by_rarity"] for rarity in rarities)
            
            add_test_result("Skins API", 
                           response.status_code == 200 and valid_response and has_all_rarities, 
                           response)
        else:
            add_test_result("Skins API", False, response)
    except Exception as e:
        add_test_result("Skins API", False, error=e)
    
    # Test /api/skins/rarity/{rarity} endpoint for each rarity
    rarities = ["mythical", "legendary", "epic", "rare", "common"]
    for rarity in rarities:
        try:
            response = requests.get(f"{BASE_URL}/skins/rarity/{rarity}")
            
            if response.status_code == 200:
                data = response.json()
                
                # Verify the response contains the expected fields
                valid_response = (
                    "rarity" in data and
                    "count" in data and
                    "skins" in data and
                    data["rarity"] == rarity and
                    isinstance(data["skins"], list)
                )
                
                add_test_result(f"Skins API - {rarity} rarity", 
                               response.status_code == 200 and valid_response, 
                               response)
            else:
                add_test_result(f"Skins API - {rarity} rarity", False, response)
        except Exception as e:
            add_test_result(f"Skins API - {rarity} rarity", False, error=e)

# The following tests require authentication
# Since we can't easily test the Steam callback, we'll simulate authentication
# by creating a mock JWT token for testing purposes

# Note: In a real-world scenario, you would need to authenticate with Steam
# and get a real token. For testing purposes, we'll skip this step and note
# that these endpoints require authentication.

def test_authenticated_endpoints():
    print("\n⚠️ Authentication Required ⚠️")
    print("The following endpoints require Steam authentication:")
    print("- GET /api/user/profile")
    print("- GET /api/user/inventory")
    print("- POST /api/user/balance/add")
    print("- POST /api/cases/{case_id}/open")
    print("\nThese endpoints cannot be fully tested without a valid Steam authentication.")
    print("In a production environment, you would need to:")
    print("1. Complete the Steam OpenID authentication flow")
    print("2. Receive a valid JWT token")
    print("3. Use this token in the Authorization header for these requests")

# Test Steam API key configuration
def test_steam_api_key():
    try:
        # We'll use the Steam Web API to test if the API key is valid
        # We'll make a request to GetSupportedAPIList which doesn't require specific parameters
        api_key = None
        
        # Read the API key from the .env file
        with open('/app/backend/.env', 'r') as f:
            for line in f:
                if line.startswith('STEAM_API_KEY='):
                    api_key = line.strip().split('=')[1].strip('"\'')
                    break
        
        if not api_key:
            add_test_result("Steam API Key Configuration", False, 
                           error="Could not find STEAM_API_KEY in .env file")
            return False
            
        # Test the API key with a simple request
        url = "https://api.steampowered.com/ISteamWebAPIUtil/GetSupportedAPIList/v1/"
        params = {'key': api_key}
        
        response = requests.get(url, params=params)
        
        # Check if the response is successful
        if response.status_code == 200:
            try:
                data = response.json()
                if "apilist" in data:
                    add_test_result("Steam API Key Configuration", True, response)
                    return True
                else:
                    add_test_result("Steam API Key Configuration", False, response,
                                   error="Invalid response format from Steam API")
                    return False
            except json.JSONDecodeError:
                add_test_result("Steam API Key Configuration", False, response,
                               error="Invalid JSON response from Steam API")
                return False
        elif response.status_code == 403:
            add_test_result("Steam API Key Configuration", False, response,
                           error="Invalid Steam API key (403 Forbidden)")
            return False
        else:
            add_test_result("Steam API Key Configuration", False, response,
                           error=f"Unexpected response from Steam API: {response.status_code}")
            return False
    except Exception as e:
        add_test_result("Steam API Key Configuration", False, error=e)
        return False

# Test callback URL configuration
def test_callback_url():
    try:
        # Read the callback URL from the .env file
        callback_url = None
        with open('/app/backend/.env', 'r') as f:
            for line in f:
                if line.startswith('CALLBACK_URL='):
                    callback_url = line.strip().split('=')[1].strip('"\'')
                    break
        
        if not callback_url:
            add_test_result("Callback URL Configuration", False, 
                           error="Could not find CALLBACK_URL in .env file")
            return False
        
        # Verify the callback URL format
        expected_format = "https://zxca-github-io.onrender.com/api/auth/steam/callback"
        
        if callback_url != expected_format:
            add_test_result("Callback URL Configuration", False, 
                           error=f"Callback URL mismatch. Expected: {expected_format}, Got: {callback_url}")
            return False
        
        # In test environment, we can't actually access the domain
        # So we'll just check if the URL is properly formatted
        add_test_result("Callback URL Configuration", True)
        print(f"Callback URL is correctly configured as: {callback_url}")
        return True
            
    except Exception as e:
        add_test_result("Callback URL Configuration", False, error=e)
        return False

# Test health endpoint
def test_health_endpoint():
    try:
        response = requests.get(f"{BASE_URL}/health")
        
        # Check if response is successful and contains status
        if response.status_code == 200 and "status" in response.json():
            status = response.json()["status"]
            database = response.json().get("database", "unknown")
            
            # Since we're testing without a real database connection,
            # we expect the database to be "disconnected"
            # But the API should still return a valid response
            
            add_test_result("Health Endpoint", 
                           response.status_code == 200, 
                           response)
            
            print(f"Health status: {status}")
            print(f"Database status: {database}")
            
            return status
        else:
            add_test_result("Health Endpoint", False, response)
            return None
    except Exception as e:
        add_test_result("Health Endpoint", False, error=e)
        return None

def run_all_tests():
    print("\n🧪 Starting API Tests for Steam Authentication and Callback URLs 🧪\n")
    
    # Test basic endpoints
    test_base_endpoint()
    
    # Test Steam authentication
    steam_login_url = test_steam_login()
    if steam_login_url:
        print(f"\nSteam Login URL: {steam_login_url}")
    
    # Test Steam callback endpoint
    test_steam_callback_endpoint()
    
    # Test Steam API key configuration
    steam_api_key_valid = test_steam_api_key()
    if steam_api_key_valid:
        print("\nSteam API key is valid and working")
    
    # Test callback URL configuration
    callback_url_valid = test_callback_url()
    if callback_url_valid:
        print("\nCallback URL is properly configured")
    
    # Test cases API
    cases = test_cases_api()
    if cases:
        print(f"\nFound {len(cases)} cases with proper Steam images and prices")
    
    # Test skins API
    test_skins_api()
    
    # Test health endpoint
    health_status = test_health_endpoint()
    
    # Note about authenticated endpoints
    test_authenticated_endpoints()
    
    # Print summary
    print("\n📊 Test Summary 📊")
    print(f"Passed: {test_results['passed']}")
    print(f"Failed: {test_results['failed']}")
    print(f"Total: {test_results['passed'] + test_results['failed']}")
    
    if test_results["failed"] == 0:
        print("\n✅ All tests passed successfully!")
    else:
        print(f"\n❌ {test_results['failed']} tests failed!")
    
    return test_results

if __name__ == "__main__":
    run_all_tests()